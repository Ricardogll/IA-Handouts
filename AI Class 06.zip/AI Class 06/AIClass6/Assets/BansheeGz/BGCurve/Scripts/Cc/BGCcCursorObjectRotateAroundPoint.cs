﻿using BansheeGz.BGSpline.Curve;
using UnityEngine;

namespace BansheeGz.BGSpline.Components
{
/*
    [
        BGCc.Descriptor(
            Description = "Rotate the object around fixed position.")
    ]
    public class BGCcCursorObjectRotateAroundPoint : BGCcWithCursorObject
    {
        [SerializeField] [Tooltip("Position to rotate around.\r\n")] private Vector3 position;

        [SerializeField] [Tooltip("Rotation axis.\r\n")] private Vector3 axis = Vector3.up;

        [SerializeField] [Tooltip("Rotation speed.\r\n")] private float rotationSpeed = 50;

        // Update is called once per frame
        private void Update()
        {
            ObjectToManipulate.transform.RotateAround(position, axis, rotationSpeed*Time.deltaTime);
        }
    }
*/
}