﻿using BansheeGz.BGSpline.Components;
using UnityEditor;

namespace BansheeGz.BGSpline.Editor
{
    [CustomEditor(typeof (BGCcCursorObjectTranslate))]
    public class BGCcCursorObjectTranslateEditor : BGCcCursorObjectEditor
    {
    }
}