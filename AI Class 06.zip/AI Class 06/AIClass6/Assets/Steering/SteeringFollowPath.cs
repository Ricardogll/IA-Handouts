﻿using UnityEngine;
using System.Collections;
using BansheeGz.BGSpline.Components;
using BansheeGz.BGSpline.Curve;

public class SteeringFollowPath : MonoBehaviour {

	Move move;
	SteeringSeek seek;
    public BGCurve curve;
    
    BGCcMath bgmath;
    public float dist;
    private Vector3 closestpoint;
    public GameObject path;


    // Use this for initialization
    void Start () {
		move = GetComponent<Move>();
		seek = GetComponent<SteeringSeek>();

        // TODO 1: Calculate the closest point in the range [0,1] from this gameobject to the path
        //BGCurvePoint curve_point;

        bgmath = path.GetComponent<BGCcMath>();
        closestpoint = bgmath.CalcPositionByClosestPoint(transform.position);
        //move.movement = closestpoint - transform.position;
        //move.movement.Normalize();
        //move.movement *= move.max_mov_acceleration;
        seek.Steer(closestpoint);

        dist = bgmath.GetDistance();
        //Vector3 aux;
        // closest_point = curve.Points[0].PositionWorld - transform.position;
        //int point = 0;

        //for (int i = 0; i < curve.PointsCount; i++)
        //{

        //    aux = curve.Points[i].PositionWorld - transform.position;

        //    if (aux.magnitude < closest_point.magnitude)
        //    {
        //        closest_point = aux;
        //        point = i;
        //    }
        //}


    }
	
	// Update is called once per frame
	void Update () 
	{
        // TODO 2: Check if the tank is close enough to the desired point
        // If so, create a new point further ahead in the path

        float aux = (closestpoint - move.transform.position).magnitude;
        
        if( aux < 0.01f){
            closestpoint = bgmath.CalcPositionByDistanceRatio(dist + 0.1f);
            seek.Steer(closestpoint);
            dist = bgmath.GetDistance();
        }

        Debug.DrawLine(transform.position, closestpoint, Color.cyan);

        

        



    }

	void OnDrawGizmosSelected() 
	{

		if(isActiveAndEnabled)
		{
			// Display the explosion radius when selected
			Gizmos.color = Color.green;
			// Useful if you draw a sphere were on the closest point to the path
		}

	}
}
